<?php
/* Smarty version 3.1.39, created on 2021-06-30 03:40:35
  from 'C:\xampp\htdocs\practica1\ejercicio1\templates\Cabeceras\Footer.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.39',
  'unifunc' => 'content_60dbcb9355ff70_53458546',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '0feb9beef7e0a47cbd941d232590e4891d756dc8' => 
    array (
      0 => 'C:\\xampp\\htdocs\\practica1\\ejercicio1\\templates\\Cabeceras\\Footer.tpl',
      1 => 1625017233,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_60dbcb9355ff70_53458546 (Smarty_Internal_Template $_smarty_tpl) {
?></div>
      <!--JavaScript at end of body for optimized loading-->
      <?php echo '<script'; ?>
 type="text/javascript" src="Framework/Materialize/js/materialize.min.js"><?php echo '</script'; ?>
>
    </body>
  </html><?php }
}
