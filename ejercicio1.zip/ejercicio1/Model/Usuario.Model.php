<?php

Class Usuario
{ 
   
    public function BuscarUsuario($user)
    { 
        echo "en procesosisi";
        echo "proximamente";

    }

}






?>