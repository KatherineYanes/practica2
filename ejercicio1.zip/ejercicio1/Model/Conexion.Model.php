<?php

Class Conexion extends mysqli
{ 
  function ___Construct()
  {
     $servidor="localhost";
     $pass="";
     $user="root";
     $DB="Inventario";

     parent::___Construct($servidor, $user, $pass, $DB);
     $this->query("SET NAMES'UTF8';");
     $this->connect_errno ? die ('Error en la conexion'): $error="Conectado a".$DB;
     echo $error;
  }

}

?>